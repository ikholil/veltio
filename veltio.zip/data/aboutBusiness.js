export const aboutBusiness = [
    {
        id: 1,
        title: 'Great Speakers', 
        desc: 'Lorem ipsum dolor xc all sit amet, consectetur ',
        img:'/image/about/microphone.png'
    },
    {
        id: 2,
        title: 'New People', 
        desc: 'Lorem ipsum dolor xc all sit amet, consectetur ',
        img:'/image/about/people.png'
    },
    {
        id: 3,
        title: 'Networking', 
        desc: 'Lorem ipsum dolor xc all sit amet, consectetur ',
        img:'/image/about/diagram.png'
    },
    {
        id: 4,
        title: 'Have Fun', 
        desc: 'Lorem ipsum dolor xc all sit amet, consectetur ',
        img:'/image/about/party.png'
    }
]
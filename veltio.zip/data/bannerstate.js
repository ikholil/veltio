export const bannerStates = [
    {
        title: 'Journalists',
        number:150,
    },
    {
        title:"CEO's",
        number: 60
    },
    {
        title: 'Speakers',
        number: 55,
    },
    {
        title:'Attendees',
        number: 4500
    }
]
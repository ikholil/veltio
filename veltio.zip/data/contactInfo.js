export const contactInfo = [
    {
        id: 1, 
        title: 'Tickets Info',
        contacts: {
            email: 'Contact@gmail.com',
            phone: '+123 456 789 110',
            address: '123H, San Fransisco, California'
        }
    },
    {
        id: 2, 
        title: 'Programme Details',
        contacts: {
            email: 'Contact@gmail.com',
            phone: '+123 456 789 110',
            address: '123H, San Fransisco, California'
        }
    },
    {
        id: 3, 
        title: 'Partnerships  Info',
        contacts: {
            email: 'Contact@gmail.com',
            phone: '+123 456 789 110',
            address: '123H, San Fransisco, California'
        }
    }
]
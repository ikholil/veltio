export const galleryImages = [
  "/image/gallery/gallery1.png",
  "/image/gallery/gallery2.png",
  "/image/gallery/gallery3.png",
  "/image/gallery/gallery4.png",
  "/image/gallery/gallery5.png",
  "/image/gallery/gallery6.png",
];

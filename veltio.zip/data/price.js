export const pricing = [
    {
        title: 'Basic Pass',
        price: 150,
        features: ['Conference Tickets', 'One catered lunch', 'Private Access', 'Experts Contacts']
    },
    {
        title: 'Standard Pass',
        price: 250,
        features: ['Conference Tickets', 'One catered lunch', 'Private Access', 'Experts Contacts']
    },
    {
        title: 'Premium Pass',
        price: 450,
        features: ['Conference Tickets', 'One catered lunch', 'Private Access', 'Experts Contacts']
    }
]
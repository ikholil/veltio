export const reviews = [
    {
        id: 1, 
        image: '/image/review/shape.png',
        desc: '   Lorem ipsum at most dolor sit amet, consectetur adipiscing elit. Nulla posuere tristique diam, sociis sem facilisi. Libero lois dinonisl morbi.'
    },
    {
        id: 2, 
        image: '/image/review/shape.png',
        desc: '   Lorem ipsum at most dolor sit amet, consectetur adipiscing elit. Nulla posuere tristique diam, sociis sem facilisi. Libero lois dinonisl morbi.'
    },
    {
        id: 3, 
        image: '/image/review/shape.png',
        desc: '   Lorem ipsum at most dolor sit amet, consectetur adipiscing elit. Nulla posuere tristique diam, sociis sem facilisi. Libero lois dinonisl morbi.'
    }
]
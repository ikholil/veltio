export const speakers = [
    {
        id: 1,
        name: 'Robard Milan',
        biography: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod.',
        experience: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit.',
        photo: '/image/team/team1.png',
        business: 8,
        entrepreneur: 9,
        links: {
            facebook: 'https://facebook.com',
            instagram: 'https://instagram.com',
            twitter:'https://twitter.com',
            linkedin:'https://linkedin.com'
        }
    },
    {
        id:2,
        name: 'Richard Bandi',
        biography: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod.',
        experience: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit.',
        business: 8,
        entrepreneur: 9,
        photo: '/image/team/team2.png',
        links: {
            facebook: 'https://facebook.com',
            instagram: 'https://instagram.com',
            twitter:'https://twitter.com',
            linkedin:'https://linkedin.com'
        }
    },
    {
        id:3,
        name: 'Monika Moni',
        biography: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod.',
        experience: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit.',
        photo: '/image/team/team3.png',
        business: 8,
        entrepreneur: 9,
        links: {
            facebook: 'https://facebook.com',
            instagram: 'https://instagram.com',
            twitter:'https://twitter.com',
            linkedin:'https://linkedin.com'
        }
    },
    {
        id: 4,
        name: 'Sara Gomez',
        biography: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod.',
        experience: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit.',
        business: 8,
        entrepreneur: 9,
        photo: '/image/team/team4.png',
        links: {
            facebook: 'https://facebook.com',
            instagram: 'https://instagram.com',
            twitter:'https://twitter.com',
            linkedin:'https://linkedin.com'
        }
    },
    {
        id: 5,
        name: 'Santa Gomez',
        biography: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod.',
        experience: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit.',
        photo: '/image/team/team5.png',
        business: 8,
        entrepreneur: 9,
        links: {
            facebook: 'https://facebook.com',
            instagram: 'https://instagram.com',
            twitter:'https://twitter.com',
            linkedin:'https://linkedin.com'
        }
    },
    {
        id: 6,
        name: 'Sara Nowmi',
        biography: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod.',
        experience: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit.',
        photo: '/image/team/team6.png',
        business: 8,
        entrepreneur: 9,
        links: {
            facebook: 'https://facebook.com',
            instagram: 'https://instagram.com',
            twitter:'https://twitter.com',
            linkedin:'https://linkedin.com'
        }
    },
    {
        id: 7,
        name: 'Sara Clown',
        biography: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod.',
        experience: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit.',
        photo: '/image/team/team7.png',
        business: 8,
        entrepreneur: 9,
        links: {
            facebook: 'https://facebook.com',
            instagram: 'https://instagram.com',
            twitter:'https://twitter.com',
            linkedin:'https://linkedin.com'
        }
    }, 
    {
        id: 8,
        name: 'Sara Laura',
        biography: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod.',
        experience: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit, quam mauris varius quis amet. Integer nisl, ut eget bibendum mauris aenean euismod. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ullamcorper mattis lectus pellentesque eu. Sed amet, duis vitae sapien non. Diam ac elit.',
        photo: '/image/team/team8.png',
        business: 8,
        entrepreneur: 9,
        links: {
            facebook: 'https://facebook.com',
            instagram: 'https://instagram.com',
            twitter:'https://twitter.com',
            linkedin:'https://linkedin.com'
        }
    }
]
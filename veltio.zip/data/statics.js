export const statics = [
    {
        title: 'Tickets Booked',
        number: 1125,
        icon: '/image/statics/ticket-icon.png'
    },
    {
        title: 'Usefull Sessions',
        number: 450,
        icon: '/image/statics/calender-icon.png'
    },
    {
        title: 'Speakers',
        number: 55,
        icon: '/image/statics/microphone-icon.png'
    }
]